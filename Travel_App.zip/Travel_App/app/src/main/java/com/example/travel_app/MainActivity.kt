package com.example.travel_app

import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    var currentimage = 0

    lateinit var image:ImageView

    var places= arrayOf("AKSHARDHAM","LOTUS TEMPLE","RED FORT","QUTUB MINAR")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val next=findViewById<ImageButton>(R.id.btn1)
        val prev=findViewById<ImageButton>(R.id.btn2)
        val placename=findViewById<TextView>(R.id.tvname)

        next.setOnClickListener {

        val idCurrentImageString="pic$currentimage"//getting id of current image pic
       //i have to get int add associated with each id
            val idCurrentImageInt=this.resources.getIdentifier(idCurrentImageString,"id",packageName)
            image=findViewById(idCurrentImageInt)//passing the int add to get the pic
            image.alpha=0f

            currentimage=(currentimage+1)
            val idImageToShowString="pic$currentimage"
            val idImageToShowInt=this.resources.getIdentifier(idImageToShowString,"id",packageName)
            image=findViewById(idCurrentImageInt)
            image.alpha=1f

            placename.text=places[currentimage]
        }

        prev.setOnClickListener {
            val idCurrentImageString="pic$currentimage"//getting id of current image pic
            //i have to get int add associated with each id
            val idCurrentImageInt=this.resources.getIdentifier(idCurrentImageString,"id",packageName)
            image=findViewById(idCurrentImageInt)//passing the int add to get the pic
            image.alpha=0f

            currentimage=(4+currentimage-1)%4
            val idImageToShowString="pic$currentimage"
            val idImageToShowInt=this.resources.getIdentifier(idImageToShowString,"id",packageName)
            image=findViewById(idCurrentImageInt)
            image.alpha=1f
            placename.text=places[currentimage]
        }



        }

    }
